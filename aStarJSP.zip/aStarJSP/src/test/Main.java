package test;

import java.io.IOException;
import route.ImageTest;

public class Main {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		route.ImageTest test = new route.ImageTest();
		//test.getRoute();

	}

}
