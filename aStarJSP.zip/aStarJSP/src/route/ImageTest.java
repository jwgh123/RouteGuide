package route;


import java.io.BufferedWriter;

import java.io.File;

import java.io.FileWriter;
import java.io.IOException;

import javax.imageio.ImageIO;

import java.awt.Color;
import java.awt.image.BufferedImage;

public class ImageTest {
	/*private static ImageTest instance = new ImageTest();
	public static ImageTest getInstance() {
		return instance;
	}*/
	public ImageTest() {
		
	}
	private static class LazyHolder{
		public static final ImageTest INSTANCE = new ImageTest();
	}
	public static ImageTest getInstance() {
		return LazyHolder.INSTANCE;
	}
	static int pixel_rate = 1;
	static String write_txt = "test.txt";
	static String read_image = "c:\\intel\\maze1.jpg";
	static BufferedImage image;
	static int threshold[] = new int[5];
	static int RED = new Color(255,0,0).getRGB(); 
	
	

	public void getRoute(int x1, int y1, int x2, int y2) throws IOException {
		
	
		File imgFile = null;

		BufferedWriter writer = null;
		BufferedWriter writer2 = null;

		int num;


		try {
			imgFile = new File(read_image);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		image = getImage(imgFile);
		writer = new BufferedWriter(new FileWriter("maze.txt", true));
		int[][] maps;
		maps = new int[image.getWidth()][image.getHeight()];

		for (int i = 0; i < image.getHeight(); i += pixel_rate) {
			for (int j = 0; j < image.getWidth(); j += pixel_rate) {

				num = getBrightness(new Color(image.getRGB(j, i)));
				if (num < 1) {
					writer.write(String.format("%s", "■"));
					maps[i][j] = 1;
				} else {
					writer.write(String.format("%s", "□"));
					maps[i][j] = 0;
				}
			}
			writer.newLine();
		}

		writer.close();

		
		writer2 = new BufferedWriter(new FileWriter("route.txt", true));
		

		//int x1 = 149;
		//int y1 = 0;
		//int x2 = 203;
		//int y2 = 100;
		MapInfo info = new MapInfo(maps, maps[0].length, maps.length, new Node(x1, y1), new Node(x2, y2));
		new AStar().start(info);

		for (int i = 0; i < maps.length; i++) {
			for (int j = 0; j < maps[i].length; j++) {
				if (maps[i][j] == 0) {
					writer2.write(String.format("%s", "□"));
					
				} else if (maps[i][j] == 1) {
					writer2.write(String.format("%s", "■"));
				} else {
					writer2.write(String.format("%s", "★"));
					image.setRGB(j, i, RED);
				}
			}

			writer2.newLine();
		}
		ImageIO.write(image, "png", new File("C:\\Users\\정지운\\eclipse-workspace\\aStarJSP\\route.png"));
		writer2.close();		
		
		deleteFile(); // 지도 만들고, 출발, 도착지 등 좌표정보를 다 알면 추가할 함수임
		
	}
	
	public void deleteFile() { //파일 삭제
		String delete1 = "maze.txt";
		String delete2 = "route.txt"; 
		File f1 = new File(delete1);
		File f2 = new File(delete2);
		f1.delete();
		f2.delete();
	}
	
	private static int getBrightness(Color color) {
		double brightness = Math.sqrt(
				0.299 * color.getRed() * color.getRed() + 0.587 * color.getGreen() * color.getGreen() + 0.114 * color.getBlue() * color.getBlue());
		return (int) brightness * 6 / 255;
	}

	private static BufferedImage getImage(File file) throws IOException {

		BufferedImage originalImage = ImageIO.read(file);
		return originalImage;
	}


}
