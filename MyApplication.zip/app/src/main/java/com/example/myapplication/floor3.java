package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Spinner;

import java.util.ArrayList;

public class floor3 extends AppCompatActivity {

    Button button;
    ArrayList arrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_floor3);

        arrayList = new ArrayList();
        arrayList.add("1층");
        arrayList.add("2층");
        arrayList.add("3층");

        final String[] select_item = {""};


        Spinner spinner = (Spinner) findViewById(R.id.spinner1);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_spinner_dropdown_item, arrayList);
        spinner.setAdapter(adapter);

        Button button = (Button) findViewById(R.id.button_spinner3);

        ImageButton button3 = (ImageButton)findViewById(R.id.imageButtonhyun);

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(floor3.this, zone_hyun.class);
                startActivity(intent);
            }

        });


        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                select_item[0] = String.valueOf(arrayList.get(arg2));
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {

            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (select_item[0].equals("2층")) {
                    Intent intent = new Intent(floor3.this, floor2.class);
                    startActivity(intent);
                    finish();

                } else if (select_item[0].equals("1층")) {
                    Intent intent = new Intent(floor3.this, zone_select.class);
                    startActivity(intent);
                    finish();
                }
            }
        });
    }
}
