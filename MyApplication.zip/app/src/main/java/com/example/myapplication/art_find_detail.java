package com.example.myapplication;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import static com.example.myapplication.art_find.IPCONFIG;

public class art_find_detail extends AppCompatActivity {
Bitmap bitmap;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_art_find_detail);

        Intent intent = getIntent(); // 보내온 Intent를 얻는다

        String link = "http://"+IPCONFIG+"/";
        String link2 = intent.getStringExtra("id");
        String link3 = ".jpg";
        final String link4 = link + link2 + link3;


        ImageView imageView = (ImageView)findViewById(R.id.imageView);
        Thread mThread = new Thread() {
            @Override
            public void run() {
                try {
                    URL url = new URL(link4);

                    // Web에서 이미지를 가져온 뒤
                    // ImageView에 지정할 Bitmap을 만든다
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setDoInput(true); // 서버로 부터 응답 수신
                    conn.connect();

                    InputStream is = conn.getInputStream(); // InputStream 값 가져오기
                    bitmap = BitmapFactory.decodeStream(is); // Bitmap으로 변환

                } catch (MalformedURLException e) {
                    e.printStackTrace();

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        };

        mThread.start(); // Thread 실행

        try {
            // 메인 Thread는 별도의 작업 Thread가 작업을 완료할 때까지 대기해야한다
            // join()를 호출하여 별도의 작업 Thread가 종료될 때까지 메인 Thread가 기다리게 한다
            mThread.join();

            // 작업 Thread에서 이미지를 불러오는 작업을 완료한 뒤
            // UI 작업을 할 수 있는 메인 Thread에서 ImageView에 이미지를 지정한다
            imageView.setImageBitmap(bitmap);

        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        TextView name = (TextView)findViewById(R.id.textView20);
        TextView artist = (TextView)findViewById(R.id.textView21);
        TextView year = (TextView)findViewById(R.id.textView22);
        TextView info = (TextView)findViewById(R.id.textView23);
        TextView zone = (TextView)findViewById(R.id.zone);

        TextView kname = (TextView)findViewById(R.id.textView30);

        kname.setText("("+intent.getStringExtra("kname")+")");
        name.setText("<"+intent.getStringExtra("name")+">");
        artist.setText(intent.getStringExtra("artist"));
        year.setText(intent.getStringExtra("year")+" 년도");
        info.setText(intent.getStringExtra("info"));
    }
}
