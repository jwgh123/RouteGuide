package com.example.myapplication;

import android.app.Activity;

public class art_inform extends Activity {

    /*

    private static String TAG = "phpquerytest";

    String myJSON;

    private static final String TAG_RESULTS = "result";
    private static final String TAG_ID = "a_id";
    private static final String TAG_NAME = "a_name";
    private static final String TAG_ARTIST = "a_artist";
    private static final String TAG_YEAR = "a_year";
    private static final String TAG_INFO = "a_info";

    ArrayList<HashMap<String, String>> artList;
    JSONArray arts = null;

    ListView list;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_art_inform);
        list = (ListView) findViewById(R.id.listView);
        artList = new ArrayList<HashMap<String, String>>();
        getData("http://192.168.141.195/PHP_connection.php");
    }

    protected void showList() {
        try {
            JSONObject jsonObj = new JSONObject(myJSON);
            arts = jsonObj.getJSONArray(TAG_RESULTS);

            for (int i = 0; i < arts.length(); i++)
            {
                JSONObject c = arts.getJSONObject(i);
                String id = c.getString(TAG_ID);
                String name = c.getString(TAG_NAME);
                String artist = c.getString(TAG_ARTIST);
                String year = c.getString(TAG_YEAR);
                String info = c.getString(TAG_INFO);

                HashMap<String, String> arts = new HashMap<String, String>();

                arts.put(TAG_ID, id);
                arts.put(TAG_NAME, name);
                arts.put(TAG_ARTIST, artist);
                arts.put(TAG_YEAR, year);
                arts.put(TAG_INFO, info);

                TextView textView1 = (TextView)findViewById(R.id.textView1);
                TextView textView2 = (TextView)findViewById(R.id.textView2);
                TextView textView3 = (TextView)findViewById(R.id.textView3);
                TextView textView4 = (TextView)findViewById(R.id.textView4);

                textView1.setText(name);
                textView2.setText(artist);
                textView3.setText(year);
                textView4.setText(info);

                artList.add(arts);
            }

            ListAdapter adapter = new SimpleAdapter(

                    art_inform.this, artList, R.layout.list_item,
                    new String[]{TAG_ID, TAG_NAME, TAG_ARTIST,TAG_YEAR,TAG_INFO},
                    new int[]{R.id.id, R.id.name, artist, year,R.id.info}
            );
            list.setAdapter(adapter);

        }
        catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void getData(String url) {
        class GetDataJSON extends AsyncTask<String, Void, String> {
            @Override
            protected String doInBackground(String... params) {

                String uri = params[0];

                BufferedReader bufferedReader = null;
                try {
                    URL url = new URL(uri);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    StringBuilder sb = new StringBuilder();

                    if(con.getResponseCode() == con.HTTP_OK){
                        Log.d("test", "debug 확인");
                    }

                    bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));

                    int i=0;
                    String json;
                    while ((json = bufferedReader.readLine()) != null) {
                        sb.append(json + "\n");
                        i++;
                    }
                    return sb.toString().trim();

                } catch (Exception e) {
                    return null;
                }
            }
            @Override
            protected void onPostExecute(String result) {
                myJSON = result;
                showList();
            }
        }
        GetDataJSON g = new GetDataJSON();
        g.execute(url);

    }
    */
}