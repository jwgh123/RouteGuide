package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import org.json.JSONException;
import org.json.JSONObject;


public class qr extends AppCompatActivity {
    //view Objects
    private Button buttonScan;
    String x1,y1, z1;
    String rx1, ry1;
    //qr code scanner object
    private IntentIntegrator qrScan;
    //Handler handler = new Handler();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qr);

        //View Objects
        buttonScan = (Button) findViewById(R.id.buttonScan);
        //http://192.168.0.11/aStarJSP
        //intializing scan object
        qrScan = new IntentIntegrator(this);

        //button onClick
        buttonScan.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                //scan option
                qrScan.setPrompt("Scanning...");
                //qrScan.setOrientationLocked(false);
                qrScan.initiateScan();
            }
        });
    }

    //Getting the scan results
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null) {
            //qrcode 가 없으면
            if (result.getContents() == null) {
                Toast.makeText(qr.this, "취소!", Toast.LENGTH_SHORT).show();
            } else {
                //qrcode 결과가 있으면
                Toast.makeText(qr.this, "스캔완료!", Toast.LENGTH_SHORT).show();
                try {
                    //data를 json으로 변환
                    JSONObject obj = new JSONObject(result.getContents());

                    x1=obj.getString("x1");
                    y1=obj.getString("y1");
                    z1=obj.getString("z1");
                    rx1=obj.getString("rx1");
                    ry1=obj.getString("ry1");
                    Intent intent = new Intent(qr.this, qr_dest.class);
                    intent.putExtra("x1",x1);
                    intent.putExtra("y1",y1);
                    intent.putExtra("rx1",rx1);
                    intent.putExtra("ry1",ry1);
                    intent.putExtra("z1",z1);
                    startActivity(intent);

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

}