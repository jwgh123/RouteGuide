package com.example.myapplication;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.WindowManager;
import android.widget.TextView;


public class start extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_start);
        TextView textView = (TextView)findViewById(R.id.start_font);

        Typeface typeFace = Typeface.createFromAsset(getAssets(), "font/210_Sumusaleuibom_B.ttf");
        textView.setTypeface(typeFace);

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            public void run() {
                Intent intent = new Intent(start.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        }, 2500);

    }

}
