package com.example.myapplication;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import static com.example.myapplication.art_find.IPCONFIG;

public class qr_dest3 extends AppCompatActivity {
    String x1;
    String y1;
    String z1;
    String rx1, ry1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qr_dest3);
        Intent intent = getIntent();
        x1 = intent.getExtras().getString("x1");
        y1 = intent.getExtras().getString("y1");
        z1 = intent.getExtras().getString("z1");
        rx1 = intent.getExtras().getString("rx1");
        ry1 = intent.getExtras().getString("ry1");

        Button button=(Button)findViewById(R.id.inform);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String x2 = "186";
                String y2 = "35";
                String z2 = "1";
                String rx2 = "240";
                String ry2 = "212";

                try {
                    String ans;
                    CustomTask task = new CustomTask();
                    ans = task.execute(x1,y1,z1, x2,y2, z2, rx1, ry1, rx2, ry2).get();
                    Log.i("리턴 값",ans);

                    Intent intent1 = new Intent(qr_dest3.this, qr_image.class);
                    startActivity(intent1);
                } catch (Exception e) {

                }

            }

        });
        Button button1=(Button)findViewById(R.id.office);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String x2 = "137";
                String y2 = "39";
                String z2 = "1";
                String rx2 = "197";
                String ry2 = "213";

                try {
                    String ans;
                    CustomTask task = new CustomTask();
                    ans = task.execute(x1,y1,z1, x2,y2, z2, rx1, ry1, rx2, ry2).get();
                    Log.i("리턴 값",ans);

                    Intent intent1 = new Intent(qr_dest3.this, qr_image.class);
                    startActivity(intent1);
                } catch (Exception e) {

                }

            }

        });
        Button button2=(Button)findViewById(R.id.special);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String x2 = "108";
                String y2 = "44";
                String z2 = "1";
                String rx2 = "170";
                String ry2 = "216";

                try {
                    String ans;
                    CustomTask task = new CustomTask();
                    ans = task.execute(x1,y1,z1, x2,y2, z2, rx1, ry1, rx2, ry2).get();
                    Log.i("리턴 값",ans);

                    Intent intent1 = new Intent(qr_dest3.this, qr_image.class);
                    startActivity(intent1);
                } catch (Exception e) {

                }

            }

        });
        Button button3=(Button)findViewById(R.id.mtoilet);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String x2 = "135";
                String y2 = "61";
                String z2 = "1";
                String rx2 = "186";
                String ry2 = "223";

                try {
                    String ans;
                    CustomTask task = new CustomTask();
                    ans = task.execute(x1,y1,z1, x2,y2, z2, rx1, ry1, rx2, ry2).get();
                    Log.i("리턴 값",ans);

                    Intent intent1 = new Intent(qr_dest3.this, qr_image.class);
                    startActivity(intent1);
                } catch (Exception e) {

                }

            }

        });
        Button button4=(Button)findViewById(R.id.wtoilet);
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String x2 = "177";
                String y2 = "79";
                String z2 = "1";
                String rx2 = "212";
                String ry2 = "232";

                try {
                    String ans;
                    CustomTask task = new CustomTask();
                    ans = task.execute(x1,y1,z1, x2,y2, z2, rx1, ry1, rx2, ry2).get();
                    Log.i("리턴 값",ans);

                    Intent intent1 = new Intent(qr_dest3.this, qr_image.class);
                    startActivity(intent1);
                } catch (Exception e) {

                }

            }

        });
        Button button5=(Button)findViewById(R.id.modern);
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String x2 = "82";
                String y2 = "72";
                String z2 = "1";
                String rx2 = "132";
                String ry2 = "231";

                try {
                    String ans;
                    CustomTask task = new CustomTask();
                    ans = task.execute(x1,y1,z1, x2,y2, z2, rx1, ry1, rx2, ry2).get();
                    Log.i("리턴 값",ans);

                    Intent intent1 = new Intent(qr_dest3.this, qr_image.class);
                    startActivity(intent1);
                } catch (Exception e) {

                }

            }

        });
        Button button6=(Button)findViewById(R.id.escal1);
        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String x2 = "159";
                String y2 = "132";
                String z2 = "1";
                String rx2 = "169";
                String ry2 = "252";

                try {
                    String ans;
                    CustomTask task = new CustomTask();
                    ans = task.execute(x1,y1,z1, x2,y2, z2, rx1, ry1, rx2, ry2).get();
                    Log.i("리턴 값",ans);

                    Intent intent1 = new Intent(qr_dest3.this, qr_image.class);
                    startActivity(intent1);
                } catch (Exception e) {

                }

            }

        });
        Button button7=(Button)findViewById(R.id.stair1);
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String x2 = "168";
                String y2 = "101";
                String z2 = "1";
                String rx2 = "195";
                String ry2 = "240";

                try {
                    String ans;
                    CustomTask task = new CustomTask();
                    ans = task.execute(x1,y1,z1, x2,y2, z2, rx1, ry1, rx2, ry2).get();
                    Log.i("리턴 값",ans);

                    Intent intent1 = new Intent(qr_dest3.this, qr_image.class);
                    startActivity(intent1);
                } catch (Exception e) {

                }

            }

        });
        Button button8=(Button)findViewById(R.id.garden);
        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String x2 = "64";
                String y2 = "153";
                String z2 = "1";
                String rx2 = "84";
                String ry2 = "263";

                try {
                    String ans;
                    CustomTask task = new CustomTask();
                    ans = task.execute(x1,y1,z1, x2,y2, z2, rx1, ry1, rx2, ry2).get();
                    Log.i("리턴 값",ans);

                    Intent intent1 = new Intent(qr_dest3.this, qr_image.class);
                    startActivity(intent1);
                } catch (Exception e) {

                }

            }

        });
        Button button9=(Button)findViewById(R.id.sance);
        button9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String x2 = "168";
                String y2 = "48";
                String z2 = "2";
                String rx2 = "226";
                String ry2 = "119";

                try {
                    String ans;
                    CustomTask task = new CustomTask();
                    ans = task.execute(x1,y1,z1, x2,y2, z2, rx1, ry1, rx2, ry2).get();
                    Log.i("리턴 값",ans);

                    Intent intent1 = new Intent(qr_dest3.this, qr_image.class);
                    startActivity(intent1);
                } catch (Exception e) {

                }

            }

        });
        Button button10=(Button)findViewById(R.id.toilet2);
        button10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String x2 = "138";
                String y2 = "38";
                String z2 = "2";
                String rx2 = "206";
                String ry2 = "114";

                try {
                    String ans;
                    CustomTask task = new CustomTask();
                    ans = task.execute(x1,y1,z1, x2,y2, z2, rx1, ry1, rx2, ry2).get();
                    Log.i("리턴 값",ans);

                    Intent intent1 = new Intent(qr_dest3.this, qr_image.class);
                    startActivity(intent1);
                } catch (Exception e) {

                }

            }

        });
        Button button11=(Button)findViewById(R.id.escal2);
        button11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String x2 = "139";
                String y2 = "62";
                String z2 = "2";
                String rx2 = "193";
                String ry2 = "126";

                try {
                    String ans;
                    CustomTask task = new CustomTask();
                    ans = task.execute(x1,y1,z1, x2,y2, z2, rx1, ry1, rx2, ry2).get();
                    Log.i("리턴 값",ans);

                    Intent intent1 = new Intent(qr_dest3.this, qr_image.class);
                    startActivity(intent1);
                } catch (Exception e) {

                }

            }

        });
        Button button12=(Button)findViewById(R.id.mid);
        button12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String x2 = "69";
                String y2 = "54";
                String z2 = "2";
                String rx2 = "139";
                String ry2 = "123";

                try {
                    String ans;
                    CustomTask task = new CustomTask();
                    ans = task.execute(x1,y1,z1, x2,y2, z2, rx1, ry1, rx2, ry2).get();
                    Log.i("리턴 값",ans);

                    Intent intent1 = new Intent(qr_dest3.this, qr_image.class);
                    startActivity(intent1);
                } catch (Exception e) {

                }

            }

        });
        Button button13=(Button)findViewById(R.id.old);
        button13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String x2 = "57";
                String y2 = "116";
                String z2 = "2";
                String rx2 = "90";
                String ry2 = "153";

                try {
                    String ans;
                    CustomTask task = new CustomTask();
                    ans = task.execute(x1,y1,z1, x2,y2, z2, rx1, ry1, rx2, ry2).get();
                    Log.i("리턴 값",ans);

                    Intent intent1 = new Intent(qr_dest3.this, qr_image.class);
                    startActivity(intent1);
                } catch (Exception e) {

                }

            }

        });
        Button button14=(Button)findViewById(R.id.stair2);
        button14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String x2 = "168";
                String y2 = "101";
                String z2 = "2";
                String rx2 = "195";
                String ry2 = "142";

                try {
                    String ans;
                    CustomTask task = new CustomTask();
                    ans = task.execute(x1,y1,z1, x2,y2, z2, rx1, ry1, rx2, ry2).get();
                    Log.i("리턴 값",ans);

                    Intent intent1 = new Intent(qr_dest3.this, qr_image.class);
                    startActivity(intent1);
                } catch (Exception e) {

                }

            }

        });
        Button button15=(Button)findViewById(R.id.food);
        button15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String x2 = "160";
                String y2 = "137";
                String z2 = "2";
                String rx2 = "170";
                String ry2 = "157";

                try {
                    String ans;
                    CustomTask task = new CustomTask();
                    ans = task.execute(x1,y1,z1, x2,y2, z2, rx1, ry1, rx2, ry2).get();
                    Log.i("리턴 값",ans);

                    Intent intent1 = new Intent(qr_dest3.this, qr_image.class);
                    startActivity(intent1);
                } catch (Exception e) {

                }

            }

        });
        Button button16=(Button)findViewById(R.id.vod);
        button16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String x2 = "137";
                String y2 = "41";
                String z2 = "3";
                String rx2 = "205";
                String ry2 = "22";

                try {
                    String ans;
                    CustomTask task = new CustomTask();
                    ans = task.execute(x1,y1,z1, x2,y2, z2, rx1, ry1, rx2, ry2).get();
                    Log.i("리턴 값",ans);

                    Intent intent1 = new Intent(qr_dest3.this, qr_image.class);
                    startActivity(intent1);
                } catch (Exception e) {

                }

            }

        });
        Button button17=(Button)findViewById(R.id.exp);
        button17.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String x2 = "176";
                String y2 = "41";
                String z2 = "3";
                String rx2 = "236";
                String ry2 = "22";

                try {
                    String ans;
                    CustomTask task = new CustomTask();
                    ans = task.execute(x1,y1,z1, x2,y2, z2, rx1, ry1, rx2, ry2).get();
                    Log.i("리턴 값",ans);

                    Intent intent1 = new Intent(qr_dest3.this, qr_image.class);
                    startActivity(intent1);
                } catch (Exception e) {

                }

            }

        });
        Button button18=(Button)findViewById(R.id.rest);
        button18.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String x2 = "165";
                String y2 = "61";
                String z2 = "3";
                String rx2 = "216";
                String ry2 = "32";

                try {
                    String ans;
                    CustomTask task = new CustomTask();
                    ans = task.execute(x1,y1,z1, x2,y2, z2, rx1, ry1, rx2, ry2).get();
                    Log.i("리턴 값",ans);

                    Intent intent1 = new Intent(qr_dest3.this, qr_image.class);
                    startActivity(intent1);
                } catch (Exception e) {

                }

            }

        });
        Button button19=(Button)findViewById(R.id.leo);
        button19.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String x2 = "83";
                String y2 = "78";
                String z2 = "3";
                String rx2 = "137";
                String ry2 = "42";

                try {
                    String ans;
                    CustomTask task = new CustomTask();
                    ans = task.execute(x1,y1,z1, x2,y2, z2, rx1, ry1, rx2, ry2).get();
                    Log.i("리턴 값",ans);

                    Intent intent1 = new Intent(qr_dest3.this, qr_image.class);
                    startActivity(intent1);
                } catch (Exception e) {

                }

            }

        });
        Button button20=(Button)findViewById(R.id.vold);
        button20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String x2 = "40";
                String y2 = "132";
                String z2 = "3";
                String rx2 = "85";
                String ry2 = "63";

                try {
                    String ans;
                    CustomTask task = new CustomTask();
                    ans = task.execute(x1,y1,z1, x2,y2, z2, rx1, ry1, rx2, ry2).get();
                    Log.i("리턴 값",ans);

                    Intent intent1 = new Intent(qr_dest3.this, qr_image.class);
                    startActivity(intent1);
                } catch (Exception e) {

                }

            }

        });
        Button button21=(Button)findViewById(R.id.escal3);
        button21.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String x2 = "148";
                String y2 = "135";
                String z2 = "3";
                String rx2 = "167";
                String ry2 = "63";

                try {
                    String ans;
                    CustomTask task = new CustomTask();
                    ans = task.execute(x1,y1,z1, x2,y2, z2, rx1, ry1, rx2, ry2).get();
                    Log.i("리턴 값",ans);

                    Intent intent1 = new Intent(qr_dest3.this, qr_image.class);
                    startActivity(intent1);
                } catch (Exception e) {

                }

            }

        });
        Button button22=(Button)findViewById(R.id.stair3);
        button22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String x2 = "168";
                String y2 = "101";
                String z2 = "3";
                String rx2 = "195";
                String ry2 = "50";

                try {
                    String ans;
                    CustomTask task = new CustomTask();
                    ans = task.execute(x1,y1,z1, x2,y2, z2, rx1, ry1, rx2, ry2).get();
                    Log.i("리턴 값",ans);

                    Intent intent1 = new Intent(qr_dest3.this, qr_image.class);
                    startActivity(intent1);
                } catch (Exception e) {

                }

            }

        });
        Button button23=(Button)findViewById(R.id.art);
        button23.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String x2 = "173";
                String y2 = "174";
                String z2 = "3";
                String rx2 = "183";
                String ry2 = "77";

                try {
                    String ans;
                    CustomTask task = new CustomTask();
                    ans = task.execute(x1,y1,z1, x2,y2, z2, rx1, ry1, rx2, ry2).get();
                    Log.i("리턴 값",ans);

                    Intent intent1 = new Intent(qr_dest3.this, qr_image.class);
                    startActivity(intent1);
                } catch (Exception e) {

                }

            }

        });
    }
    class CustomTask extends AsyncTask<String, Void, String> {
        String sendMsg, receiveMsg;

        @Override
        // doInBackground의 매개값이 문자열 배열인데요. 보낼 값이 여러개일 경우를 위해 배열로 합니다.
        protected String doInBackground(String... strings) {
            try {
                String str;
                URL url = new URL("http://"+IPCONFIG+":8080/aStarJSP/data.jsp");//보낼 jsp 주소를 ""안에 작성합니다.
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                conn.setRequestMethod("POST");//데이터를 POST 방식으로 전송합니다.
                OutputStreamWriter osw = new OutputStreamWriter(conn.getOutputStream());
                sendMsg = "x1="+strings[0]+"&y1="+strings[1]+"&z1="+strings[2]+"&x2="+strings[3]+"&y2="+strings[4]+"&z2="+strings[5]+"&rx1="+strings[6]+"&ry1="+strings[7]+"&rx2="+strings[8]+"&ry2="+strings[9];
                //보낼 데이터가 여러 개일 경우 &로 구분
                osw.write(sendMsg);//OutputStreamWriter에 담아 전송
                osw.flush();
                if(conn.getResponseCode() == conn.HTTP_OK) {
                    InputStreamReader tmp = new InputStreamReader(conn.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuffer buffer = new StringBuffer();
                    while ((str = reader.readLine()) != null) {
                        buffer.append(str);
                    }
                    receiveMsg = buffer.toString();

                } else {
                    Log.i("통신 결과", conn.getResponseCode()+"에러");
                }

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            //jsp로부터 받은 리턴 값입니다.
            return receiveMsg;
        }

    }

}
