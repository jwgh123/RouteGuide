package com.example.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        LinearLayout button=(LinearLayout)findViewById(R.id.id1);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, qr.class);
                startActivity(intent);
            }

        });

        LinearLayout button1=(LinearLayout)findViewById(R.id.id2);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, art_find.class);
                startActivity(intent);
            }

        });


        LinearLayout button2=(LinearLayout)findViewById(R.id.id3);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, zone_select.class);
                startActivity(intent);
            }

        });

        LinearLayout button3=(LinearLayout)findViewById(R.id.id4);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, scrollView.class);
                startActivity(intent);
            }

        });
    }
}
