package com.example.myapplication;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

import static com.example.myapplication.art_find.IPCONFIG;

public class zone_inform extends Activity {

    /// 인텐트로 floor 들에게서 전달받아서 그 정보를 데베에서 조회해서 바로바로 가져오게 만들기
    String myJSON;

    private static final String TAG_RESULTS = "result";
    private static final String TAG_ID = "z_id";
    private static final String TAG_NAME = "z_name";
    private static final String TAG_ARTIST = "z_artist";
    private static final String TAG_YEAR = "z_year";
    private static final String TAG_INFO = "z_info";
    private static final String TAG_INFO2 = "z_info2";

    JSONArray arts = null;

    ArrayList<HashMap<String, String>> zoneList;

    ListView list;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_zone_inform);
        list = (ListView) findViewById(R.id.listView);

        zoneList = new ArrayList<HashMap<String, String>>();
        getData("http://"+IPCONFIG+"/PHP_connection2.php");
    }

    protected void showList() {
        try {
            JSONObject jsonObj = new JSONObject(myJSON);
            arts = jsonObj.getJSONArray(TAG_RESULTS);

            for (int i = 0; i < arts.length(); i++)
            {
                JSONObject c = arts.getJSONObject(i);
                String id = c.getString(TAG_ID);
                String name = c.getString(TAG_NAME);
                String artist = c.getString(TAG_ARTIST);
                String year = c.getString(TAG_YEAR);
                String info = c.getString(TAG_INFO);
                String info2 = c.getString(TAG_INFO2);

                HashMap<String, String> arts = new HashMap<String, String>();

                arts.put(TAG_ID, id);
                arts.put(TAG_NAME, name);
                arts.put(TAG_ARTIST, artist);
                arts.put(TAG_YEAR, year);
                arts.put(TAG_INFO, info);
                arts.put(TAG_INFO2, info2);

                TextView textView5 = (TextView)findViewById(R.id.textView5);
                TextView textView10 = (TextView)findViewById(R.id.textView10);
                TextView textView6 = (TextView)findViewById(R.id.textView6);
                TextView textView7 = (TextView)findViewById(R.id.textView7);
                TextView textView8 = (TextView)findViewById(R.id.textView8);
                TextView textView9 = (TextView)findViewById(R.id.textView9);

                textView5.setText(name+"이란?");
                textView10.setText("("+name+") 존");
                textView6.setText(artist);
                textView7.setText(year);
                textView8.setText(info);
                textView9.setText(info2);

                zoneList.add(arts);
            }

            ListAdapter adapter = new SimpleAdapter(

                    zone_inform.this, zoneList, R.layout.list_item,
                    new String[]{TAG_ID, TAG_NAME, TAG_ARTIST,TAG_YEAR,TAG_INFO,TAG_INFO2},
                    new int[]{R.id.id2, R.id.name2, R.id.artist2, R.id.year2,R.id.info2,R.id.info2_2}
            );
            list.setAdapter(adapter);

        }
        catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void getData(String url) {
        class GetDataJSON extends AsyncTask<String, Void, String> {
            @Override
            protected String doInBackground(String... params) {

                String uri = params[0];

                BufferedReader bufferedReader = null;
                try {
                    URL url = new URL(uri);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    StringBuilder sb = new StringBuilder();

                    if(con.getResponseCode() == con.HTTP_OK){
                        Log.d("test", "debug 확인");
                    }

                    bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));

                    int i=0;
                    String json;
                    while ((json = bufferedReader.readLine()) != null) {
                        sb.append(json + "\n");
                        i++;
                    }
                    return sb.toString().trim();

                } catch (Exception e) {
                    return null;
                }
            }
            @Override
            protected void onPostExecute(String result) {
                myJSON = result;
                showList();
            }
        }
        GetDataJSON g = new GetDataJSON();
        g.execute(url);

    }
}