package com.example.myapplication;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.io.InputStream;
import java.net.URL;

import static com.example.myapplication.art_find.IPCONFIG;

public class qr_image extends AppCompatActivity{
    Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qr_image);

        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                // TODO Auto-generated method stub

                try {
                    final ImageView iv = (ImageView) findViewById(R.id.imageView1);
                    URL url = new URL("http://"+IPCONFIG+":8080/aStarJSP/route1.png");
                    InputStream is = url.openStream();
                    final Bitmap bm = BitmapFactory.decodeStream(is);
                    handler.post(new Runnable() {

                        @Override
                        public void run() {  // 화면에 그려줄 작업
                            iv.setImageBitmap(bm);
                        }
                    });
                    final ImageView iv1 = (ImageView) findViewById(R.id.imageView2);
                    URL url1 = new URL("http://"+IPCONFIG+":8080/aStarJSP/route2.png");
                    InputStream is1 = url1.openStream();
                    final Bitmap bm1 = BitmapFactory.decodeStream(is1);
                    handler.post(new Runnable() {
                        @Override
                        public void run() {  // 화면에 그려줄 작업
                            iv1.setImageBitmap(bm1);
                        }
                    });
                    final ImageView iv2 = (ImageView) findViewById(R.id.imageView3);
                    URL url2 = new URL("http://"+IPCONFIG+":8080/aStarJSP/route3.png");
                    InputStream is2 = url2.openStream();
                    final Bitmap bm2 = BitmapFactory.decodeStream(is2);
                    handler.post(new Runnable() {

                        @Override
                        public void run() {  // 화면에 그려줄 작업
                            iv2.setImageBitmap(bm2);
                        }
                    });
                    iv.setImageBitmap(bm); //비트맵 객체로 보여주기
                    iv1.setImageBitmap(bm1); //비트맵 객체로 보여주기
                    iv2.setImageBitmap(bm2); //비트맵 객체로 보여주기
                } catch (Exception e) {

                }
            }
        });
        t.start();

        Button button=(Button)findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(qr_image.this, qr_image2.class);
                startActivity(intent);

            }

        });
    }
}
