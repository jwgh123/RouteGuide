#include <opencv2/opencv.hpp>
#include <iostream>
#include <stdio.h>

#ifdef _DEBUG 
#pragma comment (lib, "opencv_world320d.lib") 
#else 
#pragma comment (lib, "opencv_world320.lib")
#endif



using namespace cv;
using namespace std;
void resolution(Mat &image, int scale) {
	int h = image.rows;
	int w = image.cols;
	for (int y = 0; y < h / scale; y++) {
		for (int x = 0; x < w / scale; x++) {
			Mat subimage(image, Rect(scale*x, scale*y, scale, scale));
			Scalar avgvalue = mean(subimage);
			for (int mr = 0; mr < scale; mr++) {
				for (int mc = 0; mc < scale; mc++) {
					if (image.channels() == 1)
						image.at<uchar>(scale*y + mr, scale*x + mc) = avgvalue[0];
					else if (image.channels() == 3) {
						image.at<Vec3b>(scale*y + mr, scale*x + mc)[2] = avgvalue[2];
						image.at<Vec3b>(scale*y + mr, scale*x + mc)[1] = avgvalue[1];
						image.at<Vec3b>(scale*y + mr, scale*x + mc)[0] = avgvalue[0];
					}

				}
			}
		}
	}
}
void main()

{
	Mat srcimage = imread("maze.png", 0);
	namedWindow("original", WINDOW_AUTOSIZE);
	imshow("original", srcimage);

	Mat outimage;
	resize(srcimage, outimage, Size(64, 64), 0, 0, CV_INTER_LINEAR);

	imshow("out1", outimage);

	for (int y = 0; y < 64;y++) {
		printf("{");
		for (int x = 0; x < 64; x++) {
			
			if (outimage.at<uchar>(y, x) <= 100) {
				printf("1,");
			}
			else {
				printf("0,");
			}
		}
		printf("},\n");
	}
	

	printf("\n\nend");
	


	waitKey(0);
	destroyAllWindows();
	//���� �̹����� ��׷�Ʈ���� �ʰ�, ������ �� �̾Ƴ������� convolution�ؼ� �����Ű��
}
